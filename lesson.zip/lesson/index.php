<?php
error_reporting(E_ALL);

require_once 'Users.php';

$user1 = new Users('Ivan', '1984-05-24', 'sales manager', 2500);

var_dump($user1);

$userClone = clone ($user1);

echo '<br><br>';



$userClone->setPosition('driver');
$userClone->setSalary(1600);


var_dump($userClone);

printf('<p style="color: greenyellow">U nas est: %s  userov </p><br>', Users::getCountUsers());

Users::setCountUsers(9);

printf('novoe zna4eni4: %s', Users::getCountUsers());